class Circle {
  constructor(x, y, size) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.jitterSpeed = random(3, 4);
    this.jitterDirection = random(2, 3);
  }

  move() {
    this.x += this.jitterSpeed * this.jitterDirection;
    if (this.x < 0 || this.x > 10) {
      this.jitterDirection *= -1;
      this.x = constrain(this.x, 0, width);
    }
  }

  show() {
    push();
    fill("limegreen");
    strokeWeight(2)
    stroke("yellow")
    ellipse(this.x, this.y, this.size, this.size);
    pop();
  }
}

let circles = [];

function setup() {
  createCanvas(400, 400);
  for (let i = 0; i < 5; i++) {
    circles.push(new Circle(random(width), random(height), random(25, 50)));
  }
}

function draw() {
  background("orange");

  for (let circle of circles) {
    circle.move();
    circle.show();
  }
}
